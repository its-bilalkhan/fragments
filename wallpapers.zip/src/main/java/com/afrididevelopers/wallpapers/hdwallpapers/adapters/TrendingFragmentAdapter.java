package com.afrididevelopers.wallpapers.hdwallpapers.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.afrididevelopers.wallpapers.hdwallpapers.R;
import com.afrididevelopers.wallpapers.hdwallpapers.models.TrendingFragmentModel;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;


public class TrendingFragmentAdapter extends RecyclerView.Adapter<TrendingFragmentAdapter.MyViewHolder> {

    private List<TrendingFragmentModel> dataList;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        public MyViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.imageView);
        }
    }


    public TrendingFragmentAdapter(Context context, List<TrendingFragmentModel> dataList) {
        this.dataList = dataList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.trending_wallpapers_fragment_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        TrendingFragmentModel data = dataList.get(position);
        Glide
                .with(context)
                .load(data.getImageUrl())
                .centerCrop()
                .placeholder(R.drawable.image_not_found)
                .into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}