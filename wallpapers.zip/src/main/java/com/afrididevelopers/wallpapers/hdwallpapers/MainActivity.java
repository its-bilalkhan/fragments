package com.afrididevelopers.wallpapers.hdwallpapers;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.MenuItem;
import android.widget.ImageView;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;

import com.afrididevelopers.wallpapers.hdwallpapers.fragments.NewFragment;
import com.afrididevelopers.wallpapers.hdwallpapers.fragments.TrendingFragment;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import android.view.Gravity;
import android.view.View;
import android.preference.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.io.File;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    final int REQUEST_PERMISSIONS = 100;
    private AdView adView;
    private InterstitialAd interstitialAd;
    ImageView menu, drawerLogo, refresh;
    LinearLayout rating, share, more, favorite;
    DrawerLayout drawerLayout;
    boolean doubleBackToExit = false;
    AppBarLayout appBarLayout;
    TabLayout tabLayout;
    ViewPager viewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestPermissions();
        createDirectories();

        SharedPreferences sPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String isPrivacy = sPreferences.getString("isPrivacy", "");
        if(isPrivacy.equals("Yes")) {
        } else {
            Intent intent = new Intent(MainActivity.this, Privacy.class);
            startActivity(intent);
            finish();
        }

        share = findViewById(R.id.share);
        more = findViewById(R.id.more);
        rating = findViewById(R.id.rating);
        refresh = findViewById(R.id.refresh);

        menu = findViewById(R.id.menu);
        drawerLogo = findViewById(R.id.drawerLogo);
        drawerLayout = findViewById(R.id.drawerLayout);

        menu = findViewById(R.id.menu);
        appBarLayout = findViewById(R.id.appBarLayout);

        favorite = findViewById(R.id.favorite);

        viewPager = findViewById(R.id.viewpager);
        setupViewPager(viewPager);
        tabLayout = findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        viewPager.setOffscreenPageLimit(3);

        MobileAds.initialize(this,
                getResources().getString(R.string.admobAppId));
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        Glide
                .with(MainActivity.this)
                .load(R.drawable.logo)
                .placeholder(R.drawable.logo)
                .apply(RequestOptions.circleCropTransform())
                .into(drawerLogo);

        rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rating();
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share();
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moreApps();
            }
        });

        favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FavoriteActivity.class);
                startActivity(intent);
                showAds();
            }
        });

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    List<Fragment> allFragments = getSupportFragmentManager().getFragments();
                    for (Fragment fragment: allFragments) {
                        if(fragment instanceof NewFragment) {
                            ((NewFragment) fragment).reload();
                        } else if(fragment instanceof TrendingFragment) {
                            ((TrendingFragment) fragment).reload();
                        }
                    }

                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Error while loading new data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            public void onPageScrollStateChanged(int state) {}
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

            public void onPageSelected(int position) {
            }
        });

    }

    private void createDirectories(){
        File mainFolder = new File(Environment.getExternalStorageDirectory(), "HD Wallpapers");

        if (!mainFolder.exists()) {
            mainFolder.mkdirs();
        }
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExit) {
            super.onBackPressed();
            return;
        }
        doubleBackToExit = true;
        Toast.makeText(MainActivity.this, "Touch again to exit", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExit=false;
            }
        }, 2000);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAd();

    }

    public void share() {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String appName = getResources().getString(R.string.app_name);
        String shareBody = "Hey, Download "+ appName +" for Android: http://play.google.com/store/apps/details?id="+getApplication().getPackageName();
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, appName);
        sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    public void rating() {
        String appName = getResources().getString(R.string.app_name);
        new AlertDialog.Builder(MainActivity.this)
                .setTitle("Rating")
                .setMessage("If you enjoy using this application? Please take a moment to rate it.\nThanks for your support!")
                .setPositiveButton("RATE NOW",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                gotoRating();
                                dialog.cancel();
                            }
                        })
                .setNegativeButton("NO, THANKS", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                }).show();
    }

    public void gotoRating() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id="+this.getPackageName())));
        } catch (android.content.ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id="+this.getPackageName())));
        }
    }

    public void moreApps() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://search?q=pub:BF Apps Studio")));
        } catch (android.content.ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/developer?id=BF Apps Studio")));
        }
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new NewFragment(), "NEW WALLPAPERS");
        adapter.addFragment(new TrendingFragment(), "TRENDING WALLPAPERS");
        viewPager.setAdapter(adapter);

    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }

    public void loadAd() {
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (interstitialAd.isLoaded()) {
            interstitialAd.show();
        }
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if ((ContextCompat.checkSelfPermission(getApplicationContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) ||
                    (ContextCompat.checkSelfPermission(getApplicationContext(),
                            Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) ||
                    (ContextCompat.checkSelfPermission(getApplicationContext(),
                            Manifest.permission.SET_WALLPAPER) != PackageManager.PERMISSION_GRANTED)) {
                if ((ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)) ||
                        (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE)) ||
                        (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                                Manifest.permission.SET_WALLPAPER))) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Permission required")
                            .setMessage("Permission is required for this app to work!")
                            .setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    ActivityCompat.requestPermissions(MainActivity.this,
                                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                                    Manifest.permission.SET_WALLPAPER
                                            },
                                            REQUEST_PERMISSIONS);
                                }
                            })
                            .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                    Toast.makeText(MainActivity.this, "Permissions rejected! Some feature will be not working", Toast.LENGTH_LONG).show();
                                }
                            })
                            .show();
                } else {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                    Manifest.permission.SET_WALLPAPER},
                            REQUEST_PERMISSIONS);
                }
            }
        }
    }

}
