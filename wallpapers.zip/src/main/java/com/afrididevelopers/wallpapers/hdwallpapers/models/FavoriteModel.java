package com.afrididevelopers.wallpapers.hdwallpapers.models;

import android.graphics.drawable.Drawable;

public class FavoriteModel {

    public String imageId, imageUrl, imageName;

    public FavoriteModel(String imageId, String imageName, String imageUrl) {

        this.imageId = imageId;
        this.imageName = imageName;
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getImageId() {
        return imageId;
    }

    public String getImageName() {
        return imageName;
    }

}
