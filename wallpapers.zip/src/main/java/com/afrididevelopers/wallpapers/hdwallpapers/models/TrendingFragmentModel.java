package com.afrididevelopers.wallpapers.hdwallpapers.models;

import android.graphics.drawable.Drawable;

public class TrendingFragmentModel {

    public String imageId, imageUrl, imageName;

    public TrendingFragmentModel(String imageId, String imageName, String imageUrl) {

        this.imageName = imageName;
        this.imageId = imageId;
        this.imageUrl = imageUrl;
    }

    public String getImageName() {
        return imageName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getImageId() {
        return imageId;
    }
}
