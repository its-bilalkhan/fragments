package com.afrididevelopers.wallpapers.hdwallpapers.models;

import android.graphics.drawable.Drawable;

public class NewFragmentModel {

    public String imageUrl, imageId, imageName;

    public NewFragmentModel(String imageId, String imageName, String imageUrl) {

        this.imageName = imageName;
        this.imageId = imageId;
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getImageId() {
        return imageId;
    }

    public String getImageName() {
        return imageName;
    }

}
