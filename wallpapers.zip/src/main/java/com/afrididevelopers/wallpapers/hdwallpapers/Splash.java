package com.afrididevelopers.wallpapers.hdwallpapers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Splash extends AppCompatActivity {

    private Handler handler;
    private Runnable delayRunnable;
    String check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        SharedPreferences sPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String isPrivacy = sPreferences.getString("isPrivacy", "");
        if (isPrivacy.equals("Yes")) {
            handler = new Handler();
            delayRunnable = new Runnable() {

                @Override
                public void run() {

                    Intent intent = new Intent(Splash.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            };
            handler.postDelayed(delayRunnable, 2000);
        } else {
            Intent intent = new Intent(Splash.this, Privacy.class);
            startActivity(intent);
            finish();
        }

        if(!isNetworkConnected()) {
            Toast.makeText(Splash.this, "Please enable internet connection to load wallpapers from server", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }
}
