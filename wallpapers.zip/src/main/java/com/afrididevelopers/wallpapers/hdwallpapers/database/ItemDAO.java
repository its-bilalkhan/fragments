package com.afrididevelopers.wallpapers.hdwallpapers.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ItemDAO {

    /* users table */

    @Insert
    public long favoriteInsert(Favorite favorite);

    @Query("SELECT * FROM favorite WHERE imageId = :id")
    public List<Favorite> imagesGetById(int id);

    @Query("DELETE FROM favorite WHERE imageId = :id")
    abstract void imageDeleteById(int id);

    @Query("SELECT * FROM favorite")
    public List<Favorite> getAllFavorite();

}
