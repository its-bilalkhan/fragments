package com.afrididevelopers.wallpapers.hdwallpapers;

import android.app.ProgressDialog;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.afrididevelopers.wallpapers.hdwallpapers.database.AppDatabase;
import com.afrididevelopers.wallpapers.hdwallpapers.database.Favorite;
import com.afrididevelopers.wallpapers.hdwallpapers.database.ItemDAO;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.AndroidNetworking;
import com.bumptech.glide.Glide;
import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;
import com.downloader.Progress;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class ViewActivity extends AppCompatActivity {

    ImageView imageView, download, setWallpaper, addToFavorite;
    String imageId = "";
    File file;
    String dirPath, fileName;
    AppDatabase database;
    ItemDAO itemDAO;
    List<Favorite> favorites;
    String imageUrl = "";
    String imageName = "";
    ImageView back;
    boolean isDownloaded = false;
    String updateDownloadsUrl = "http://afrididevelopers.com/apps/wallpapers/app/api.php";
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_image);

        database = Room.databaseBuilder(this, AppDatabase.class, "db")
                .allowMainThreadQueries()
                .build();
        itemDAO = database.getItemDAO();

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        MobileAds.initialize(this,
                getResources().getString(R.string.admobAppId));
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        imageView = findViewById(R.id.imageView);
        back = findViewById(R.id.back);
        addToFavorite = findViewById(R.id.addToFavorite);
        download = findViewById(R.id.download);
        setWallpaper = findViewById(R.id.setWallpaper);

        PRDownloader.initialize(getApplicationContext());
        // Enabling database for resume support even after the application is killed:
/*        PRDownloaderConfig config = PRDownloaderConfig.newBuilder()
                .setDatabaseEnabled(true)
                .build();
        PRDownloader.initialize(getApplicationContext(), config);
*/
// Setting timeout globally for the download network requests:
        PRDownloaderConfig config = PRDownloaderConfig.newBuilder()
                .setReadTimeout(30_000)
                .setConnectTimeout(30_000)
                .build();
        PRDownloader.initialize(getApplicationContext(), config);

        AndroidNetworking.initialize(getApplicationContext());

        Intent intent = getIntent();
        imageId = intent.getStringExtra("imageId");
        imageUrl = intent.getStringExtra("imageUrl");
        imageName = intent.getStringExtra("imageName");

        favorites = itemDAO.imagesGetById(Integer.parseInt(imageId));

        if (favorites.size() > 0) {

            Glide
                    .with(ViewActivity.this)
                    .load(R.drawable.red_heart_icon)
                    .placeholder(R.drawable.image_not_found)
                    .into(addToFavorite);
        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        addToFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                favorites = itemDAO.imagesGetById(Integer.parseInt(imageId));

                if (favorites.size() > 0) {

                    Glide
                            .with(ViewActivity.this)
                            .load(R.drawable.heart_icon)
                            .into(addToFavorite);
                    itemDAO.imageDeleteById(Integer.parseInt(imageId));

                    Toast.makeText(ViewActivity.this, "Wallpaper removed from favorite", Toast.LENGTH_SHORT).show();
                } else {

                    Favorite favorite = new Favorite();
                    favorite.setImageId(Integer.parseInt(imageId));
                    favorite.setName(imageName);
                    favorite.setImageUrl(imageUrl);
                    itemDAO.favoriteInsert(favorite);
                    Toast.makeText(ViewActivity.this, "Wallpaper added in favorite", Toast.LENGTH_SHORT).show();

                    Glide
                            .with(ViewActivity.this)
                            .load(R.drawable.red_heart_icon)
                            .into(addToFavorite);
                }

            }
        });

        setWallpaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isDownloaded) {
                    try {
                        File file = new File(dirPath+"/"+fileName);
                        WallpaperManager wallpaperManager = WallpaperManager.getInstance(getBaseContext());
                        Bitmap myBitmap =  BitmapFactory.decodeFile(file.getAbsolutePath());
                        wallpaperManager.setBitmap(myBitmap);
                        Toast.makeText(ViewActivity.this, "Wallpaper successfully set on wallpaper", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(ViewActivity.this, "Please download wallpaper first to set on wallpaper", Toast.LENGTH_SHORT).show();
                }

            }
        });

        dirPath = Environment.getExternalStorageDirectory() + "/HD Wallpapers";
        fileName = imageName+".jpeg";
        file = new File(dirPath, fileName);

        Glide
                .with(ViewActivity.this)
                .load(imageUrl)
                .centerCrop()
                .placeholder(R.drawable.image_not_found)
                .into(imageView);

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog dialog = new ProgressDialog(ViewActivity.this);
                dialog.setTitle("Downloading...");
                dialog.setMax(100);
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                dialog.show();

                File outputDirectory = new File(Environment.getExternalStorageDirectory(), "HD Wallpapers");
                if(!outputDirectory.exists()) {
                    outputDirectory.mkdirs();
                }
                final String fileLocation = dirPath+"/"+fileName;
                int downloadId = PRDownloader.download(imageUrl, dirPath, fileName)
                        .build()
                        .setOnStartOrResumeListener(new OnStartOrResumeListener() {
                            @Override
                            public void onStartOrResume() {

                            }
                        })
                        .setOnPauseListener(new OnPauseListener() {
                            @Override
                            public void onPause() {

                            }
                        })
                        .setOnCancelListener(new OnCancelListener() {
                            @Override
                            public void onCancel() {

                            }
                        })
                        .setOnProgressListener(new OnProgressListener() {
                            @Override
                            public void onProgress(Progress progress) {
                                Long totalProgress = progress.currentBytes*100;
                                Long percent = totalProgress/progress.totalBytes;
                                dialog.setProgress(Integer.parseInt(String.valueOf(percent)));
                            }
                        })
                        .start(new OnDownloadListener() {
                            @Override
                            public void onDownloadComplete() {
                                isDownloaded = true;
                                dialog.dismiss();
                                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(new File(fileLocation))));
                                Toast.makeText(ViewActivity.this, "Download complete", Toast.LENGTH_LONG).show();
                                updateDownloads();
                            }

                            @Override
                            public void onError(Error error) {
                                Toast.makeText(ViewActivity.this, "Download error! Please try again later", Toast.LENGTH_LONG).show();
                                isDownloaded = false;
                            }

                        });

            }
        });


    }

    @Override
    public void onResume() {
        super.onResume();
//        loadAd();
    }


    public void loadAd() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        }
        }

    public void updateDownloads() {
        final RequestQueue queue = Volley.newRequestQueue(ViewActivity.this);
        final StringRequest request = new StringRequest(Request.Method.POST, updateDownloadsUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("My error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("put_data", "update_downloads");
                map.put("image_id", imageId);

                return map;
            }
        };

        queue.add(request);
    }
}
