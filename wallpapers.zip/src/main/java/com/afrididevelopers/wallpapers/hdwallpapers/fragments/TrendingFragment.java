package com.afrididevelopers.wallpapers.hdwallpapers.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.afrididevelopers.wallpapers.hdwallpapers.adapters.TrendingFragmentAdapter;
import com.afrididevelopers.wallpapers.hdwallpapers.listeners.RecyclerTouchListener;
import com.afrididevelopers.wallpapers.hdwallpapers.models.TrendingFragmentModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.afrididevelopers.wallpapers.hdwallpapers.R;
import com.afrididevelopers.wallpapers.hdwallpapers.ViewActivity;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class TrendingFragment extends Fragment {

    private List<TrendingFragmentModel> dataList;
    private RecyclerView recyclerView;
    String imageId = "";
    String imageUrl = "";
    String imageName = "";
    private TrendingFragmentAdapter adapter;
    String baseUrl = "http://afrididevelopers.com/apps/wallpapers/res/wallpapers/";
    String callAPI = "http://afrididevelopers.com/apps/wallpapers/app/api.php";
    private InterstitialAd interstitialAd;
    ProgressBar progressBar;


    public TrendingFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.trending_wallpapers_fragment, container, false);

        dataList = new ArrayList<>();

        MobileAds.initialize(getActivity(),
                getResources().getString(R.string.admobAppId));
        interstitialAd = new InterstitialAd(getActivity());
        interstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        recyclerView = view.findViewById(R.id.recyclerView);
        progressBar = view.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);

        adapter = new TrendingFragmentAdapter(getActivity(), dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),2));
        recyclerView.setAdapter(adapter);

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                TrendingFragmentModel data = dataList.get(position);

                imageId =  data.getImageId();
                imageUrl = data.getImageUrl();
                imageName = data.getImageName();
                Intent intent = new Intent(getActivity(), ViewActivity.class);
                intent.putExtra("imageId", imageId);
                intent.putExtra("imageUrl", imageUrl);
                intent.putExtra("imageName", imageName);
                startActivity(intent);
                showAds();

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        loadData();
        return view;
    }

    public void reload() {
        progressBar.setVisibility(View.VISIBLE);
        dataList.clear();
        adapter.notifyDataSetChanged();
        loadData();
    }


    public void loadData() {
        final RequestQueue queue = Volley.newRequestQueue(getActivity());
        final StringRequest request = new StringRequest(Request.Method.POST, callAPI, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressBar.setVisibility(View.GONE);
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject obj = jsonArray.getJSONObject(i);
                        if(obj.getString("response").equals("error")) {
                        } else if(obj.getString("response").equals("success")) {

                            TrendingFragmentModel data = new TrendingFragmentModel(obj.getString("id"), obj.getString("name"), baseUrl+obj.getString("name"));
                            dataList.add(data);
                            adapter.notifyDataSetChanged();

                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("My error", "" + error);
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Load failed. Please refresh", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("get_data", "get_trending_images");

                return map;
            }
        };

        queue.add(request);

    }
    @Override
    public void onResume() {
        super.onResume();
        loadAd();
    }

    public void loadAd() {
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (interstitialAd.isLoaded()) {
            interstitialAd.show();
        }
    }
}