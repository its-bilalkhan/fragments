package com.afrididevelopers.wallpapers.hdwallpapers.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.afrididevelopers.wallpapers.hdwallpapers.R;
import com.afrididevelopers.wallpapers.hdwallpapers.models.NewFragmentModel;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;


public class NewFragmentAdapter extends RecyclerView.Adapter<NewFragmentAdapter.MyViewHolder> {

    private List<NewFragmentModel> dataList;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        public MyViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.imageView);
        }
    }


    public NewFragmentAdapter(Context context, List<NewFragmentModel> dataList) {
        this.dataList = dataList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.new_wallpapers_fragment_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        NewFragmentModel data = dataList.get(position);
        Glide
                .with(context)
                .load(data.getImageUrl())
                .centerCrop()
                .placeholder(R.drawable.image_not_found)
                .into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}