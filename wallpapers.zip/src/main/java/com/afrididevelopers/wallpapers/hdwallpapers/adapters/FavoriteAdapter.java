package com.afrididevelopers.wallpapers.hdwallpapers.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.afrididevelopers.wallpapers.hdwallpapers.R;
import com.afrididevelopers.wallpapers.hdwallpapers.ViewActivity;
import com.afrididevelopers.wallpapers.hdwallpapers.database.AppDatabase;
import com.afrididevelopers.wallpapers.hdwallpapers.database.ItemDAO;
import com.afrididevelopers.wallpapers.hdwallpapers.models.FavoriteModel;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;


public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.MyViewHolder> {

    private List<FavoriteModel> dataList;
    Context context;
    ItemDAO itemDAO;
    AppDatabase database;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView, delete;

        public MyViewHolder(View view) {
            super(view);
            delete = view.findViewById(R.id.delete);
            imageView = view.findViewById(R.id.imageView);
            database = Room.databaseBuilder(context, AppDatabase.class, "db")
                    .allowMainThreadQueries()
                    .build();
            itemDAO = database.getItemDAO();
        }
    }


    public FavoriteAdapter(Context context, List<FavoriteModel> dataList) {
        this.dataList = dataList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.favorite_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        final FavoriteModel data = dataList.get(position);
        Glide
                .with(context)
                .load(data.getImageUrl())
                .centerCrop()
                .placeholder(R.drawable.image_not_found)
                .into(holder.imageView);

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                itemDAO.imageDeleteById(Integer.parseInt(data.getImageId()));
                dataList.remove(position);
                notifyDataSetChanged();
            }
        });

        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ViewActivity.class);
                intent.putExtra("imageId", data.getImageId());
                intent.putExtra("imageUrl", data.getImageUrl());
                intent.putExtra("imageName", data.getImageName());
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}