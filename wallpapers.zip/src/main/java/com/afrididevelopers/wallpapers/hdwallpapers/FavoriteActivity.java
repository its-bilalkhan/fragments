package com.afrididevelopers.wallpapers.hdwallpapers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.afrididevelopers.wallpapers.hdwallpapers.adapters.FavoriteAdapter;
import com.afrididevelopers.wallpapers.hdwallpapers.database.AppDatabase;
import com.afrididevelopers.wallpapers.hdwallpapers.database.Favorite;
import com.afrididevelopers.wallpapers.hdwallpapers.database.ItemDAO;
import com.afrididevelopers.wallpapers.hdwallpapers.listeners.RecyclerTouchListener;
import com.afrididevelopers.wallpapers.hdwallpapers.models.FavoriteModel;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FavoriteActivity extends AppCompatActivity {

    private List<FavoriteModel> dataList;
    private RecyclerView recyclerView;
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;
    String imageId = "";
    String imageUrl = "";
    String imageName = "";
    ImageView back;
    private FavoriteAdapter mAdapter;
    AppDatabase database;
    ItemDAO itemDAO;
    List<Favorite> favorites;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        database = Room.databaseBuilder(this, AppDatabase.class, "db")
                .allowMainThreadQueries()
                .build();
        itemDAO = database.getItemDAO();

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        MobileAds.initialize(this,
                getResources().getString(R.string.admobAppId));
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        dataList = new ArrayList<>();

        back = findViewById(R.id.back);
        recyclerView = findViewById(R.id.recyclerView);

        mAdapter = new FavoriteAdapter(FavoriteActivity.this, dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(FavoriteActivity.this);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setLayoutManager(new GridLayoutManager(FavoriteActivity.this,2));
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(FavoriteActivity.this, recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                FavoriteModel data = dataList.get(position);

                imageId =  data.getImageId();
                imageUrl = data.getImageUrl();
                imageName = data.getImageName();
            }

            @Override
            public void onLongClick(View view, int position) {


            }
        }));


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    public void loadData() {
        if(dataList.size() > 0) {
            dataList.clear();
            mAdapter.notifyDataSetChanged();
        }
        List<Favorite> favorites = itemDAO.getAllFavorite();
        for (int i = 0; i < favorites.size(); i++) {
            FavoriteModel data = new FavoriteModel(String.valueOf(favorites.get(i).getImageId()),
                    String.valueOf(favorites.get(i).getName()), favorites.get(i).getImageUrl());
            dataList.add(data);
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        loadData();
    //    loadAd();
    }

    public void loadAd() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        }
    }
}
