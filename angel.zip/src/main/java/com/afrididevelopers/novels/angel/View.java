package com.afrididevelopers.novels.angel;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Toast;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnDrawListener;
import com.github.barteksc.pdfviewer.listener.OnErrorListener;
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener;
import com.github.barteksc.pdfviewer.listener.OnPageChangeListener;
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle;
import com.github.barteksc.pdfviewer.util.FitPolicy;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class View extends AppCompatActivity {

    PDFView pdfView;
    MediaPlayer mediaPlayer;
    boolean nightMode = false;
    boolean sounds = true;
    boolean swipHorizontal = false;
    boolean enableDoubleTap = true;
    boolean autoSpacing = true;
    boolean fitEachPage = true;
    boolean pageSnap = true;
    boolean pageFling = true;
    boolean annotationRendering = false;
    boolean antialiasing = false;
    boolean isFirstTime = true;
    String name = "";
    String path = "";
    int defaultPage = 0;
    int counterForAds = 0;
    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        pdfView = findViewById(R.id.pdfView);

        MobileAds.initialize(this,
                getResources().getString(R.string.admobAppId));
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        Intent intent = getIntent();
        if (intent.hasExtra("from")) {
            String from = intent.getStringExtra("from");
            if (from.equals("downloads")) {
                path  = intent.getStringExtra("path");
                name  = intent.getStringExtra("name");
                loadDownloads();
            } else if (from.equals("online")) {
                path  = intent.getStringExtra("path");
                name  = intent.getStringExtra("name");
                loadOnline();
            }
        }



    }

    public void loadOnline() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(View.this);
        String defaultPageStr = sharedPreferences.getString(name, "default");
        if (!defaultPageStr.equals("default")) {
            defaultPage = Integer.parseInt(defaultPageStr);
        } else {
            defaultPage = 0;
        }

        Intent intent = getIntent();
        if (intent.hasExtra("pageNumber")) {
            defaultPage = Integer.parseInt(intent.getStringExtra("pageNumber"));
        }

        checkSettings();

        try{
            new RetrievePdfStream().execute(path);
        }
        catch (Exception e){
            Toast.makeText(this, "Failed to load Pdf. Please download it and read it from downloads", Toast.LENGTH_SHORT).show();
        }

    }

    public void loadDownloads() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(View.this);
        String defaultPageStr = sharedPreferences.getString(name, "default");
        if (!defaultPageStr.equals("default")) {
            defaultPage = Integer.parseInt(defaultPageStr);

        } else {
            defaultPage = 0;
        }

        Intent intent = getIntent();
        if (intent.hasExtra("pageNumber")) {
            defaultPage = Integer.parseInt(intent.getStringExtra("pageNumber"));
        }

        checkSettings();
        loadDownloadsView();

    }

    public void loadDownloadsView() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(View.this);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        pdfView.fromFile(new File(path)) // stream is written to bytearray - native code cannot use Java Streams
                .enableSwipe(true) // allows to block changing pages using swipe
                .swipeHorizontal(swipHorizontal)
                .enableDoubletap(enableDoubleTap)
                .defaultPage(defaultPage)
                .enableAnnotationRendering(annotationRendering) // render annotations (such as comments, colors or forms)
                .password(null)
                .scrollHandle(null)
                .enableAntialiasing(antialiasing) // improve rendering a little bit on low-res screens
                // spacing between pages in dp. To define spacing color, set view background
                .spacing(0)
                .onPageChange(new OnPageChangeListener() {
                    @Override
                    public void onPageChanged(int page, int pageCount) {
                        if (!isFirstTime) {
                            playSound();
                            editor.putString(name, String.valueOf(page));
                            editor.apply();
                        } else {
                            isFirstTime = false;
                        }

                        counterForAds = counterForAds + 1;
                        if (counterForAds == 7) {
                            loadAd();
                        } else if (counterForAds == 15) {
                            counterForAds = 0;
                            showAds();
                        }

                    }
                })
                .autoSpacing(autoSpacing)
                .pageFitPolicy(FitPolicy.WIDTH) // mode to fit pages in the view
                .fitEachPage(fitEachPage) // fit each page to the view, else smaller pages are scaled relative to largest page.
                .pageSnap(pageSnap) // snap pages to screen boundaries
                .pageFling(pageFling) // make a fling change only a single page like ViewPager
                .nightMode(nightMode) // toggle night mode
                .load();

    }

    public void checkSettings() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(View.this);
        String nightModeStr = sharedPreferences.getString("nightMode", "default");
        String soundsStr = sharedPreferences.getString("sounds", "default");
        String swipHorizontalStr = sharedPreferences.getString("swipHorizontal", "default");
        String enableDoubleTapStr = sharedPreferences.getString("enableDoubleTap", "default");
        String autoSpacingStr = sharedPreferences.getString("autoSpacing", "default");
        String fitEachPageStr = sharedPreferences.getString("fitEachPage", "default");
        String pageSnapStr = sharedPreferences.getString("pageSnap", "default");
        String pageFlingStr = sharedPreferences.getString("pageFling", "default");
        String annotationRenderingStr = sharedPreferences.getString("annotationRendering", "default");
        String antialiasingStr = sharedPreferences.getString("antialiasing", "default");

        if (nightModeStr.equals("default")) {
            nightMode = false;
        } else if (nightModeStr.equals("on")) {
            nightMode = true;
        } else if (nightModeStr.equals("off")) {
            nightMode = false;
        }

        if (soundsStr.equals("default")) {
            sounds = true;
        } else if (soundsStr.equals("on")) {
            sounds = true;
        } else if (soundsStr.equals("off")) {
            sounds = false;
        }

        if (swipHorizontalStr.equals("default")) {
            swipHorizontal = false;
        } else if (swipHorizontalStr.equals("on")) {
            swipHorizontal = true;
        } else if (swipHorizontalStr.equals("off")) {
            swipHorizontal = false;
        }

        if (enableDoubleTapStr.equals("default")) {
            enableDoubleTap = true;
        } else if (enableDoubleTapStr.equals("on")) {
            enableDoubleTap = true;
        } else if (enableDoubleTapStr.equals("off")) {
            enableDoubleTap = false;
        }

        if (autoSpacingStr.equals("default")) {
            autoSpacing = true;
        } else if (autoSpacingStr.equals("on")) {
            autoSpacing = true;
        } else if (autoSpacingStr.equals("off")) {
            autoSpacing = false;
        }

        if (fitEachPageStr.equals("default")) {
            fitEachPage = true;
        } else if (fitEachPageStr.equals("on")) {
            fitEachPage = true;
        } else if (fitEachPageStr.equals("off")) {
            fitEachPage = false;
        }

        if (pageSnapStr.equals("default")) {
            pageSnap = true;
        } else if (pageSnapStr.equals("on")) {
            pageSnap = true;
        } else if (pageSnapStr.equals("off")) {
            pageSnap = false;
        }

        if (pageFlingStr.equals("default")) {
            pageFling = true;
        } else if (pageFlingStr.equals("on")) {
            pageFling = true;
        } else if (pageFlingStr.equals("off")) {
            pageFling = false;
        }

        if (annotationRenderingStr.equals("default")) {
            annotationRendering = false;
        } else if (annotationRenderingStr.equals("on")) {
            annotationRendering = true;
        } else if (annotationRenderingStr.equals("off")) {
            annotationRendering = false;
        }

        if (antialiasingStr.equals("default")) {
            antialiasing = false;
        } else if (antialiasingStr.equals("on")) {
            antialiasing = true;
        } else if (antialiasingStr.equals("off")) {
            antialiasing = false;
        }

    }

    public void playSound() {
        if (sounds) {
            mediaPlayer = new MediaPlayer();
            mediaPlayer = MediaPlayer.create(View.this, R.raw.page_change_sound);
            mediaPlayer.start();
        }
    }

    public void loadAd() {
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (interstitialAd.isLoaded()) {
            interstitialAd.show();
        } else {
            loadAd();
        }

    }

   class RetrievePdfStream extends AsyncTask<String, Void, InputStream> {

       private ProgressDialog progressDialog;
        RetrievePdfStream() {
            progressDialog = new ProgressDialog(View.this);
        }

       @Override
       protected void onPreExecute() {
           super.onPreExecute();

           progressDialog.setTitle("Please wait");
           progressDialog.setMessage("Fetching PDF from server...");
           progressDialog.setCancelable(true);
           progressDialog.setCanceledOnTouchOutside(false);
           progressDialog.show();

       }

        @Override
        protected InputStream doInBackground(String... strings) {
            InputStream inputStream = null;

            try {
                URL url = new URL(strings[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                if (urlConnection.getResponseCode() == 200) {
                    inputStream = new BufferedInputStream(urlConnection.getInputStream());

                }
            } catch (IOException e) {
                return null;

            }
            return inputStream;
        }
        @Override
        protected void onPostExecute(InputStream inputStream) {

            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(View.this);
            SharedPreferences.Editor editor = sharedPreferences.edit();

            pdfView.fromStream(inputStream) // stream is written to bytearray - native code cannot use Java Streams
                    .enableSwipe(true) // allows to block changing pages using swipe
                    .swipeHorizontal(swipHorizontal)
                    .enableDoubletap(enableDoubleTap)
                    .defaultPage(defaultPage)
                    .enableAnnotationRendering(annotationRendering) // render annotations (such as comments, colors or forms)
                    .password(null)
                    .scrollHandle(null)
                    .enableAntialiasing(antialiasing) // improve rendering a little bit on low-res screens
                    // spacing between pages in dp. To define spacing color, set view background
                    .spacing(0)
                    .onError(new OnErrorListener() {
                        @Override
                        public void onError(Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(View.this, "Load failed please try again", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .onDraw(new OnDrawListener() {
                        @Override
                        public void onLayerDrawn(Canvas canvas, float pageWidth, float pageHeight, int displayedPage) {
                            progressDialog.dismiss();
                        }
                    })
                    .onPageChange(new OnPageChangeListener() {
                        @Override
                        public void onPageChanged(int page, int pageCount) {
                            if (!isFirstTime) {
                                playSound();
                                editor.putString(name, String.valueOf(page));
                                editor.apply();
                            } else {
                                isFirstTime = false;
                            }

                            counterForAds = counterForAds + 1;
                            if (counterForAds == 7) {
                                loadAd();
                            } else if (counterForAds == 15) {
                                counterForAds = 0;
                                showAds();
                            }
                        }
                    })
                    .autoSpacing(autoSpacing)
                    .pageFitPolicy(FitPolicy.WIDTH) // mode to fit pages in the view
                    .fitEachPage(fitEachPage) // fit each page to the view, else smaller pages are scaled relative to largest page.
                    .pageSnap(pageSnap) // snap pages to screen boundaries
                    .pageFling(pageFling) // make a fling change only a single page like ViewPager
                    .nightMode(nightMode) // toggle night mode
                    .load();

        }
    }
}
