package com.afrididevelopers.novels.angel;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    AppBarLayout appBarLayout;
    TabLayout tabLayout;
    ViewPager viewPager;
    ImageView refresh, search;
    TextView title;
    DrawerLayout drawerLayout;
    ImageView menu, drawerLogo;
    final int REQUEST_PERMISSIONS = 100;
    String feedbackUrl = "https://afrididev.000webhostapp.com/apps/angel/app/get_data.php";
    private AdView mAdView;
    boolean doubleBackToExit = false;
    private InterstitialAd mInterstitialAd;

    LinearLayout settings, rating, share, more, feedback, about;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String isPrivacy = sharedPreferences.getString("isPrivacy", "");
        if(isPrivacy.equals("Yes")) {

        } else {
            Intent intent = new Intent(MainActivity.this, Privacy.class);
            startActivity(intent);
            finish();
        }

        requestPermissions();

        File outputDirectory = new File(Environment.getExternalStorageDirectory(), "Angel");
        if(!outputDirectory.exists()) {
            outputDirectory.mkdirs();
        }

        menu = findViewById(R.id.menu);
        drawerLogo = findViewById(R.id.drawerLogo);
        drawerLayout = findViewById(R.id.drawerLayout);

        settings = findViewById(R.id.settings);
        rating = findViewById(R.id.rating);
        share = findViewById(R.id.share);
        more = findViewById(R.id.more);
        feedback = findViewById(R.id.feedback);
        about = findViewById(R.id.about);

        MobileAds.initialize(MainActivity.this,
                getResources().getString(R.string.admobAppId));
        mInterstitialAd = new InterstitialAd(MainActivity.this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        appBarLayout = findViewById(R.id.appBarLayout);
        appBarLayout = findViewById(R.id.appBarLayout);
        refresh = findViewById(R.id.refresh);

        title = findViewById(R.id.title);
        search = findViewById(R.id.search);

        viewPager = findViewById(R.id.viewpager);
        setupViewPager(viewPager);
        tabLayout = findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });

        Glide
                .with(MainActivity.this)
                .load(R.drawable.logo)
                .placeholder(R.drawable.logo)
                .apply(RequestOptions.circleCropTransform())
                .into(drawerLogo);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Search.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });


        viewPager.setOffscreenPageLimit(2);

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    List<Fragment> allFragments = getSupportFragmentManager().getFragments();
                    for (Fragment fragment: allFragments) {
                        if (fragment instanceof DownloadsFragment){
                            ((DownloadsFragment) fragment).reload();
                        } else if(fragment instanceof OnlineFragment) {
                            ((OnlineFragment) fragment).reload();
                        }
                    }

                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Error while loading data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Settings.class);
                startActivity(intent);
                showAds();

            }
        });

        rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ratting();
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                share();
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moreApps();
            }
        });

        feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFeedbackDialog();
            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAboutDialog();
            }
        });


    }


    @Override
    public void onBackPressed() {
        if (doubleBackToExit) {
            super.onBackPressed();
            return;
        }
        doubleBackToExit = true;
        Toast.makeText(MainActivity.this, "Touch again to exit", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExit=false;
            }
        }, 2000);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAd();
    }

    public void loadAd() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        }
    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new DownloadsFragment(), "DOWNLOADS");
        adapter.addFragment(new OnlineFragment(), "ONLINE");
        viewPager.setAdapter(adapter);
    }


    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }


    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if ((ContextCompat.checkSelfPermission(getApplicationContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) ||
                    (ContextCompat.checkSelfPermission(getApplicationContext(),
                            Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
                if ((ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)) ||
                        (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE))) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Permission required")
                            .setMessage("Permission is required for this app to work!")
                            .setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    ActivityCompat.requestPermissions(MainActivity.this,
                                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                                            },
                                            REQUEST_PERMISSIONS);
                                }
                            })
                            .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                    Toast.makeText(MainActivity.this, "Permissions rejected! Some feature will be not work properly", Toast.LENGTH_LONG).show();
                                }
                            })
                            .show();
                } else {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            REQUEST_PERMISSIONS);
                }
            }
        }
    }

    public void ratting() {
        String appName = getResources().getString(R.string.app_name);
        new AlertDialog.Builder(MainActivity.this)
                .setTitle("Rating")
                .setMessage("If you enjoy using this application? Please take a moment to rate it.\nThanks for your support!")
                .setPositiveButton("RATE NOW",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                gotoRatting();
                                dialog.cancel();
                            }
                        })
                .setNegativeButton("NO, THANKS", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                }).show();
    }

    public void share() {
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        String appName = getResources().getString(R.string.app_name);
        String shareBody = "Hey, Download "+ appName +" for Android: http://play.google.com/store/apps/details?id="+getApplication().getPackageName();
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, appName);
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    public void moreApps() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://search?q=pub:Afridi Developers")));
        } catch (android.content.ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/developer?id=Afridi Developers")));
        }
    }

    public void gotoRatting() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id="+this.getPackageName())));
        } catch (android.content.ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id="+this.getPackageName())));
        }
    }

    public void showAboutDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.about_dialog_view);
        dialog.setCancelable(true);

        final RelativeLayout cancel = dialog.findViewById(R.id.cancel);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }


    public void showFeedbackDialog() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.feedback_dialog_view);
        dialog.setCancelable(true);

        final RelativeLayout cancel = dialog.findViewById(R.id.cancel);
        final com.google.android.material.textfield.TextInputEditText userNameView = dialog.findViewById(R.id.userNameView);
        final com.google.android.material.textfield.TextInputEditText messageView = dialog.findViewById(R.id.messageView);
        final Button submitFeedback = dialog.findViewById(R.id.submitFeedback);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        submitFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = userNameView.getText().toString();
                String userMessage = messageView.getText().toString();
                if(userName.equals("")) {
                    userName = "NA";
                }
                if (userMessage.equals("")) {
                    Toast.makeText(MainActivity.this, "Please enter feedback", Toast.LENGTH_SHORT).show();
                } else {
                    sentFeedback(userName, userMessage);
                }
            }
        });


        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
    }

    public void sentFeedback(final String userName, final String userMessage) {
        final RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        final StringRequest request = new StringRequest(Request.Method.POST, feedbackUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject obj = jsonArray.getJSONObject(i);
                        if (obj.getString("response").equals("success")) {
                            Toast.makeText(MainActivity.this, "Feedback sent successfully", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Something is wrong! Please try again", Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this, "Something is wrong! Please try again", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Something is wrong! Please try again", Toast.LENGTH_SHORT).show();
                Log.i("My error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("put_data", "feedback");
                map.put("name", userName);
                map.put("message", userMessage);

                return map;
            }
        };

        queue.add(request);
    }
}