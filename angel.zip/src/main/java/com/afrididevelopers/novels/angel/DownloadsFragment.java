package com.afrididevelopers.novels.angel;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.provider.MediaStore;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.afrididevelopers.novels.angel.adapters.DownloadsAdapter;
import com.afrididevelopers.novels.angel.listeners.RecyclerItemClickListener;
import com.afrididevelopers.novels.angel.models.DownloadsModel;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;


public class DownloadsFragment extends Fragment {

    List<DownloadsModel> dataList;
    DownloadsAdapter adapter;
    RecyclerView recyclerView;
    LinearLayout notFound;
    private InterstitialAd mInterstitialAd;
    ProgressBar progress;
    DownloadsModel file;
    int totalPages = 0;

    public DownloadsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.downloads_fragment, container, false);

        MobileAds.initialize(getActivity(),
                getResources().getString(R.string.admobAppId));
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        recyclerView = view.findViewById(R.id.recyclerView);
        notFound = view.findViewById(R.id.notFound);
        progress = view.findViewById(R.id.progress);
        notFound.setVisibility(View.INVISIBLE);

        dataList = new ArrayList<>();
        adapter = new DownloadsAdapter(getActivity(), dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                DownloadsModel data = dataList.get(position);
                Intent intent = new Intent(getActivity(), Details.class);
                intent.putExtra("from", "downloads");
                intent.putExtra("name", data.getName());
                intent.putExtra("format", data.getFormat());
                intent.putExtra("path", data.getPath());
                startActivity(intent);
                showAds();

            }

            @Override
            public void onItemLongClick(View view, int position) {

                showPopupMenu(view, position);
            }
        }));

        loadData();
        return view;
    }

    public void reload() {
        loadData();
        loadAd();
    }

    public void loadData() {
        try {
            if(!dataList.isEmpty()) {
                dataList.clear();
                adapter.notifyDataSetChanged();
            }
            File file;
            String name, format, path;
            Iterator<String> filePath = getMedia().iterator();
            while (filePath.hasNext()) {
                path = filePath.next();
                file = new File(path);
                name = file.getName();
                name = name.substring(0, name.lastIndexOf("."));
                format = path.substring(path.lastIndexOf(".") + 1);

                DownloadsModel data = new DownloadsModel(name, format, path);
                dataList.add(data);
                adapter.notifyDataSetChanged();
            }
        }
        catch (Exception e){ }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAd();
    }

    public void loadAd() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {

        }
    }

    public void showPopupMenu(View view, int position){
        file = dataList.get(position);
        Context wrapper = new ContextThemeWrapper(view.getContext(), R.style.popupMenuStyle); //remove it for without style
        final PopupMenu popupMenu = new PopupMenu(wrapper, view, Gravity.RIGHT);
        final Menu menu = popupMenu.getMenu();
        popupMenu.getMenuInflater().inflate(R.menu.downloads_popup_menu, menu);
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.open:
                        DownloadsModel data = dataList.get(position);
                        Intent intent = new Intent(getActivity(), Details.class);
                        intent.putExtra("from", "downloads");
                        intent.putExtra("name", data.getName());
                        intent.putExtra("format", data.getFormat());
                        intent.putExtra("path", data.getPath());
                        startActivity(intent);
                        showAds();
                        return true;
                    case R.id.delete:
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setTitle("Delete");
                        builder.setMessage("Are you sure you want to delete this pdf file?");

                        builder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                try {
                                    MediaScannerConnection.scanFile(getActivity(),
                                            new String[]{file.getPath()},
                                            null,
                                            new MediaScannerConnection.OnScanCompletedListener() {
                                                @Override
                                                public void onScanCompleted(String path, Uri uri) {
                                                    File selectedFile = new File(file.getPath());
                                                    if (uri != null) {
                                                        if(selectedFile.delete()){
                                                            getActivity().getContentResolver().delete(uri, null, null);
                                                            getActivity().runOnUiThread(new Runnable() {
                                                                public void run() {
                                                                    dataList.remove(position);
                                                                    adapter.notifyItemRemoved(position);
                                                                    adapter.notifyItemRangeChanged(position, dataList.size());
                                                                    Toast.makeText(getActivity(), "File deleted successfully", Toast.LENGTH_SHORT).show();
                                                                }
                                                            });
                                                        }else{
                                                            getActivity().runOnUiThread(new Runnable() {
                                                                public void run() {
                                                                    Toast.makeText(getActivity(), "Can't delete file", Toast.LENGTH_SHORT).show();                                                                        }
                                                            });
                                                        }
                                                    }else{
                                                        getActivity().runOnUiThread(new Runnable() {
                                                            public void run() {
                                                                Toast.makeText(getActivity(), "Can't delete file", Toast.LENGTH_SHORT).show();                                                                        }
                                                        });
                                                    }
                                                }
                                            });
                                }catch (Exception e){
                                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog = builder.create();
                        dialog.show();
                        return true;
                    default:
                        return false;
                }
            }
        });
        popupMenu.show();
    }


    public ArrayList<String> getMedia() {
        Uri uri = MediaStore.Files.getContentUri("external");
        HashSet<String> fileItemHashSet = new HashSet<>();
        String[] projection = null;
        String sortOrder = null;
        String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf");
        String[] selectionArgsPdf = new String[]{ mimeType };
        Cursor cursor = getActivity().getContentResolver().query(uri, projection,
                MediaStore.Files.FileColumns.MIME_TYPE + "=?",  selectionArgsPdf, sortOrder);
        try {
            cursor.moveToFirst();
            do{
                    if (cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)).contains("Angel")) {
                        fileItemHashSet.add((cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA))));
                    }
            }while(cursor.moveToNext());
            cursor.close();
        } catch (Exception e) { }
        ArrayList<String> downloadedList = new ArrayList<>(fileItemHashSet);
        if(downloadedList.isEmpty()) {
            notFound.setVisibility(View.VISIBLE);
            progress.setVisibility(View.INVISIBLE);
        } else {
            progress.setVisibility(View.INVISIBLE);
        }
        recyclerView.setItemViewCacheSize(downloadedList.size());
        return downloadedList;
    }

}