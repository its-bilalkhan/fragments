package com.afrididevelopers.novels.angel;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.pdf.PdfRenderer;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.afrididevelopers.novels.angel.models.DownloadsModel;
import com.afrididevelopers.novels.angel.models.OnlineModel;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.Progress;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Details extends AppCompatActivity {

    View onlineLine;
    MediaPlayer mediaPlayer;
    LinearLayout onlineLayout;
    LinearLayout likesLayout, dislikesLayout, downloadsLayout;
    TextView name, pages, size, type;
    Button read, gotoPage, download;
    TextView likes, dislikes, downloads;
    String from = "";
    int totalPages = 0;
    String fileName = "";
    String fileFormat = "";
    String filePath = "";

    String fileId = "";
    String filePages = "";
    String fileSize = "";
    String fileDownloads = "";
    String fileLikes = "";
    String fileDislikes = "";
    ImageView back;
    String likeUrl = "https://afrididev.000webhostapp.com/apps/angel/app/add_like.php";
    String dislikeUrl = "https://afrididev.000webhostapp.com/apps/angel/app/add_dislike.php";
    String downloadUrl = "https://afrididev.000webhostapp.com/apps/angel/app/add_downloads.php";
    boolean isDownloading = false;
    boolean sounds = true;

    private AdView mAdView;
    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        onlineLine = findViewById(R.id.onlineLine);
        onlineLayout = findViewById(R.id.onlineLayout);

        back = findViewById(R.id.back);
        name = findViewById(R.id.name);
        pages = findViewById(R.id.pages);
        size = findViewById(R.id.size);
        type = findViewById(R.id.type);

        read = findViewById(R.id.read);
        gotoPage = findViewById(R.id.gotoPage);
        download = findViewById(R.id.download);

        likes = findViewById(R.id.likes);
        dislikes = findViewById(R.id.dislikes);
        downloads = findViewById(R.id.downloads);

        likesLayout = findViewById(R.id.likesLayout);
        dislikesLayout = findViewById(R.id.dislikesLayout);
        downloadsLayout = findViewById(R.id.downloadsLayout);

        MobileAds.initialize(Details.this,
                getResources().getString(R.string.admobAppId));
        mInterstitialAd = new InterstitialAd(Details.this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        Intent intent = getIntent();
        from = intent.getStringExtra("from");
        if(from.equals("downloads")) {
            onlineLine.setVisibility(View.GONE);
            onlineLayout.setVisibility(View.GONE);
            download.setVisibility(View.GONE);
            fileName = intent.getStringExtra("name");
            fileFormat = intent.getStringExtra("format");
            filePath = intent.getStringExtra("path");
            fromDownloadLoadData(fileName, fileFormat, filePath);
        } else if (from.equals("online")) {
            fileName = intent.getStringExtra("name");
            fileFormat = intent.getStringExtra("format");
            filePath = intent.getStringExtra("url");

            fileId = intent.getStringExtra("id");
            filePages = intent.getStringExtra("pages");
            fileSize = intent.getStringExtra("size");
            fileDownloads = intent.getStringExtra("downloads");
            fileLikes = intent.getStringExtra("likes");
            fileDislikes = intent.getStringExtra("dislikes");

            totalPages = Integer.parseInt(filePages);
            name.setText(fileName);
            pages.setText(filePages);
            size.setText(fileSize);
            type.setText(fileFormat);
            likes.setText(fileLikes);
            dislikes.setText(fileDislikes);
            downloads.setText(fileDownloads);
        }

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(Details.this);
        String soundsStr = sharedPreferences.getString("sounds", "default");
        if (soundsStr.equals("default")) {
            sounds = true;
        } else if (soundsStr.equals("on")) {
            sounds = true;
        } else if (soundsStr.equals("off")) {
            sounds = false;
        }


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        likesLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                likesLayout.setEnabled(false);
                likes.setText(String.valueOf(Integer.parseInt(fileLikes)+1));
                playSound();
                addLike();
            }
        });

        dislikesLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dislikesLayout.setEnabled(false);
                dislikes.setText(String.valueOf(Integer.parseInt(fileDislikes)+1));
                playSound();
                addDislike();
            }
        });

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(from.equals("downloads")) {
                    Intent intent = new Intent(Details.this, com.afrididevelopers.novels.angel.View.class);
                    intent.putExtra("from", "downloads");
                    intent.putExtra("path", String.valueOf(filePath));
                    intent.putExtra("name", String.valueOf(fileName));
                    startActivity(intent);
                    showAds();
                } else if (from.equals("online")) {
                    Intent intent = new Intent(Details.this, com.afrididevelopers.novels.angel.View.class);
                    intent.putExtra("from", "online");
                    intent.putExtra("path", String.valueOf(filePath));
                    intent.putExtra("name", String.valueOf(fileName));
                    startActivity(intent);
                }

            }
        });

        gotoPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Details.this);
                builder.setTitle("Enter Page Number");
                final EditText input = new EditText(Details.this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER);
                input.setHint("e.g 56");
                builder.setView(input);
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String number = "";
                        number = input.getText().toString();
                        if (number.equals("")) {
                            Toast.makeText(Details.this, "Please enter page number", Toast.LENGTH_SHORT).show();
                        } else if (Integer.parseInt(number) < 1 || Integer.parseInt(number) > totalPages){
                            Toast.makeText(Details.this, "Please enter page number between 1 to "+totalPages, Toast.LENGTH_SHORT).show();
                        } else {
                            int pageNumber = Integer.parseInt(number);
                            pageNumber = pageNumber - 1;

                            if(from.equals("downloads")) {
                                Intent intent = new Intent(Details.this, com.afrididevelopers.novels.angel.View.class);
                                intent.putExtra("from", "downloads");
                                intent.putExtra("path", String.valueOf(filePath));
                                intent.putExtra("name", String.valueOf(fileName));
                                intent.putExtra("pageNumber", String.valueOf(pageNumber));
                                startActivity(intent);
                                showAds();
                            } else if (from.equals("online")) {
                                Intent intent = new Intent(Details.this, com.afrididevelopers.novels.angel.View.class);
                                intent.putExtra("from", "online");
                                intent.putExtra("path", String.valueOf(filePath));
                                intent.putExtra("name", String.valueOf(fileName));
                                intent.putExtra("pageNumber", String.valueOf(pageNumber));
                                startActivity(intent);
                            }

                        }
                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            }
        });

        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isDownloading) {
                    Toast.makeText(Details.this, "Download already is running", Toast.LENGTH_SHORT).show();
                } else {
                    isDownloading = true;
                   downloadNow();
                }
            }
        });

    }

    public void downloadNow() {
        ProgressDialog dialog = new ProgressDialog(Details.this);
        downloads.setText(String.valueOf(Integer.parseInt(fileDownloads)+1));
        addDownload();

        dialog.setTitle("Downloading...");
        dialog.setMax(100);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.show();

        File outputDirectory = new File(Environment.getExternalStorageDirectory(), "Angel");
        if(!outputDirectory.exists()) {
            outputDirectory.mkdirs();
        }
        String dirPath = Environment.getExternalStorageDirectory() + "/Angel";
		final String fileLocation = dirPath+"/"+fileName+"."+fileFormat;
        int downloadId = PRDownloader.download(filePath, dirPath, fileName+"."+fileFormat)
                .build()
                .setOnStartOrResumeListener(new OnStartOrResumeListener() {
                    @Override
                    public void onStartOrResume() {

                    }
                })
                .setOnProgressListener(new OnProgressListener() {
                    @Override
                    public void onProgress(Progress progress) {
                        Long totalProgress = progress.currentBytes*100;
                        Long percent = totalProgress/progress.totalBytes;
                        dialog.setProgress(Integer.parseInt(String.valueOf(percent)));
                    }
                })
                .start(new OnDownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        dialog.dismiss();
                        sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(new File(fileLocation))));
                        Toast.makeText(Details.this, "Download completed", Toast.LENGTH_LONG).show();
                        isDownloading = false;
                    }

                    @Override
                    public void onError(Error error) {
                        dialog.dismiss();
                        Toast.makeText(Details.this, "Download error! Please try again later", Toast.LENGTH_LONG).show();
                        isDownloading = false;
                    }

                });
    }

    public void addDownload() {
        final RequestQueue queue = Volley.newRequestQueue(Details.this);
        final StringRequest request = new StringRequest(Request.Method.POST, downloadUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("My error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("add_data", "download");
                map.put("id", fileId);

                return map;
            }
        };

        queue.add(request);
    }


    public void addLike() {
        final RequestQueue queue = Volley.newRequestQueue(Details.this);
        final StringRequest request = new StringRequest(Request.Method.POST, likeUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("My error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("add_data", "like");
                map.put("id", fileId);

                return map;
            }
        };

        queue.add(request);
    }

    public void addDislike() {
        final RequestQueue queue = Volley.newRequestQueue(Details.this);
        final StringRequest request = new StringRequest(Request.Method.POST, dislikeUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("My error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("add_data", "dislike");
                map.put("id", fileId);

                return map;
            }
        };

        queue.add(request);
    }

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String defaultPageStr = sharedPreferences.getString(String.valueOf(fileName), "default");
        if (!defaultPageStr.equals("default")) {
            read.setText("Continue");
        }
    }

    public void loadAd() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        }
    }

    public void fromDownloadLoadData(String fName, String fFormat, String fPath) {
        try {
                File file = new File(fPath);
                String fSize = getFileSize(file.length());
                totalPages = countPages(new File(fPath));

            name.setText(fName);
            if (totalPages == 0) {
                pages.setText("NA");
            } else {
                pages.setText(String.valueOf(totalPages));
            }
            size.setText(fSize);
            type.setText(fFormat);
        }
        catch (Exception e){ }
    }

    private int countPages(File pdfFile) throws IOException {
        try {

            ParcelFileDescriptor parcelFileDescriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
            PdfRenderer pdfRenderer = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                pdfRenderer = new PdfRenderer(parcelFileDescriptor);
                return pdfRenderer.getPageCount();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public static String getFileSize(long size) {
        String fileSize = null;
        double b = size;
        double kb = size/1024.0;
        double mb = ((size/1024.0)/1024.0);
        double gb = (((size/1024.0)/1024.0)/1024.0);
        double tb = ((((size/1024.0)/1024.0)/1024.0)/1024.0);
        DecimalFormat dec = new DecimalFormat("0.0");
        if(tb > 1) {
            fileSize = dec.format(tb).concat(" TB");
        } else if(gb > 1) {
            fileSize = dec.format(gb).concat(" GB");
        } else if(mb > 1) {
            fileSize = dec.format(mb).concat(" MB");
        } else if(kb > 1) {
            fileSize = dec.format(kb).concat(" KB");
        } else {
            fileSize = dec.format(b).concat(" Bytes");
        }
        return fileSize;
    }

    public void playSound() {
        if (sounds) {
            mediaPlayer = new MediaPlayer();
            mediaPlayer = MediaPlayer.create(Details.this, R.raw.click_sound);
            mediaPlayer.start();
        }
    }

}
