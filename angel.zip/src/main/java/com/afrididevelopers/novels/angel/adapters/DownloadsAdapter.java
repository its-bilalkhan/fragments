package com.afrididevelopers.novels.angel.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

import com.afrididevelopers.novels.angel.R;
import com.afrididevelopers.novels.angel.models.DownloadsModel;
import com.bumptech.glide.Glide;

public class DownloadsAdapter extends RecyclerView.Adapter<DownloadsAdapter.MyViewHolder> {

    private List<DownloadsModel> dataList;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView name, details;

        public MyViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.icon);
            name = view.findViewById(R.id.name);
        }
    }


    public DownloadsAdapter(Context context, List<DownloadsModel> dataList) {
        this.dataList = dataList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.downloads_fragment_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        DownloadsModel data = dataList.get(position);
        holder.name.setText(data.getName());

        Glide
                .with(context)
                .load(R.drawable.pdf_icon)
                .placeholder(R.drawable.pdf_icon)
                .into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}