package com.afrididevelopers.novels.angel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ImageView;

import com.github.angads25.toggle.interfaces.OnToggledListener;
import com.github.angads25.toggle.model.ToggleableView;
import com.github.angads25.toggle.widget.LabeledSwitch;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class Settings extends AppCompatActivity {

    ImageView back;
    LabeledSwitch nightMode, sounds, swipHorizontal, enableDoubleTap, autoSpacing,
            fitEachPage, pageSnap, pageFling, annotationRendering, antialiasing;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        back = findViewById(R.id.back);

        nightMode = findViewById(R.id.nightMode);
        sounds = findViewById(R.id.sounds);
        swipHorizontal = findViewById(R.id.swipHorizontal);
        enableDoubleTap = findViewById(R.id.enableDoubleTap);
        autoSpacing = findViewById(R.id.autoSpacing);
        fitEachPage = findViewById(R.id.fitEachPage);
        pageSnap = findViewById(R.id.pageSnap);
        pageFling = findViewById(R.id.pageFling);
        annotationRendering = findViewById(R.id.annotationRendering);
        antialiasing = findViewById(R.id.antialiasing);

        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        checkSettings();
        settings();

    }

    public void checkSettings() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(Settings.this);
        String nightModeStr = sharedPreferences.getString("nightMode", "default");
        String soundsStr = sharedPreferences.getString("sounds", "default");
        String swipHorizontalStr = sharedPreferences.getString("swipHorizontal", "default");
        String enableDoubleTapStr = sharedPreferences.getString("enableDoubleTap", "default");
        String autoSpacingStr = sharedPreferences.getString("autoSpacing", "default");
        String fitEachPageStr = sharedPreferences.getString("fitEachPage", "default");
        String pageSnapStr = sharedPreferences.getString("pageSnap", "default");
        String pageFlingStr = sharedPreferences.getString("pageFling", "default");
        String annotationRenderingStr = sharedPreferences.getString("annotationRendering", "default");
        String antialiasingStr = sharedPreferences.getString("antialiasing", "default");

        if (nightModeStr.equals("default")) {
            nightMode.setOn(false);
        } else if (nightModeStr.equals("on")) {
            nightMode.setOn(true);
        } else if (nightModeStr.equals("off")) {
            nightMode.setOn(false);
        }

        if (soundsStr.equals("default")) {
            sounds.setOn(true);
        } else if (soundsStr.equals("on")) {
            sounds.setOn(true);
        } else if (soundsStr.equals("off")) {
            sounds.setOn(false);
        }

        if (swipHorizontalStr.equals("default")) {
            swipHorizontal.setOn(false);
        } else if (swipHorizontalStr.equals("on")) {
            swipHorizontal.setOn(true);
        } else if (swipHorizontalStr.equals("off")) {
            swipHorizontal.setOn(false);
        }

        if (enableDoubleTapStr.equals("default")) {
            enableDoubleTap.setOn(true);
        } else if (enableDoubleTapStr.equals("on")) {
            enableDoubleTap.setOn(true);
        } else if (enableDoubleTapStr.equals("off")) {
            enableDoubleTap.setOn(false);
        }

        if (autoSpacingStr.equals("default")) {
            autoSpacing.setOn(true);
        } else if (autoSpacingStr.equals("on")) {
            autoSpacing.setOn(true);
        } else if (autoSpacingStr.equals("off")) {
            autoSpacing.setOn(false);
        }

        if (fitEachPageStr.equals("default")) {
            fitEachPage.setOn(true);
        } else if (fitEachPageStr.equals("on")) {
            fitEachPage.setOn(true);
        } else if (fitEachPageStr.equals("off")) {
            fitEachPage.setOn(false);
        }

        if (pageSnapStr.equals("default")) {
            pageSnap.setOn(true);
        } else if (pageSnapStr.equals("on")) {
            pageSnap.setOn(true);
        } else if (pageSnapStr.equals("off")) {
            pageSnap.setOn(false);
        }

        if (pageFlingStr.equals("default")) {
            pageFling.setOn(true);
        } else if (pageFlingStr.equals("on")) {
            pageFling.setOn(true);
        } else if (pageFlingStr.equals("off")) {
            pageFling.setOn(false);
        }

        if (annotationRenderingStr.equals("default")) {
            annotationRendering.setOn(false);
        } else if (annotationRenderingStr.equals("on")) {
            annotationRendering.setOn(true);
        } else if (annotationRenderingStr.equals("off")) {
            annotationRendering.setOn(false);
        }

        if (antialiasingStr.equals("default")) {
            antialiasing.setOn(false);
        } else if (antialiasingStr.equals("on")) {
            antialiasing.setOn(true);
        } else if (antialiasingStr.equals("off")) {
            antialiasing.setOn(false);
        }

    }

    public void settings() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(Settings.this);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        nightMode.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("nightMode", "on");
                    editor.apply();
                } else {
                    editor.putString("nightMode", "off");
                    editor.apply();
                }
            }
        });

        sounds.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("sounds", "on");
                    editor.apply();
                } else {
                    editor.putString("sounds", "off");
                    editor.apply();
                }
            }
        });

        swipHorizontal.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("swipHorizontal", "on");
                    editor.apply();
                } else {
                    editor.putString("swipHorizontal", "off");
                    editor.apply();
                }
            }
        });

        enableDoubleTap.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("enableDoubleTap", "on");
                    editor.apply();
                } else {
                    editor.putString("enableDoubleTap", "off");
                    editor.apply();
                }
            }
        });

        autoSpacing.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("autoSpacing", "on");
                    editor.apply();
                } else {
                    editor.putString("autoSpacing", "off");
                    editor.apply();
                }
            }
        });

        fitEachPage.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("fitEachPage", "on");
                    editor.apply();
                } else {
                    editor.putString("fitEachPage", "off");
                    editor.apply();
                }
            }
        });

        pageSnap.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("pageSnap", "on");
                    editor.apply();
                } else {
                    editor.putString("pageSnap", "off");
                    editor.apply();
                }
            }
        });

        pageFling.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("pageFling", "on");
                    editor.apply();
                } else {
                    editor.putString("pageFling", "off");
                    editor.apply();
                }
            }
        });

        annotationRendering.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("annotationRendering", "on");
                    editor.apply();
                } else {
                    editor.putString("annotationRendering", "off");
                    editor.apply();
                }
            }
        });

        antialiasing.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (isOn) {
                    editor.putString("antialiasing", "on");
                    editor.apply();
                } else {
                    editor.putString("antialiasing", "off");
                    editor.apply();
                }
            }
        });

    }
}
