package com.afrididevelopers.novels.angel.models;

public class OnlineModel {

    public String id, category, name, author, pages, size, format, downloads, likes, dislikes, path, dateTime;

    public OnlineModel(String id, String category, String name, String author, String pages, String size, String format,
                          String downloads, String likes, String dislikes, String path, String dateTime) {

        this.id = id;
        this.category = category;
        this.name = name;
        this.author = author;
        this.pages = pages;
        this.size = size;
        this.format = format;
        this.downloads = downloads;
        this.likes = likes;
        this.dislikes = dislikes;
        this.path = path;
        this.dateTime = dateTime;
    }

    public String getId() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getPages() {
        return pages;
    }

    public String getSize() {
        return size;
    }

    public String getFormat() {
        return format;
    }

    public String getDownloads() {
        return downloads;
    }

    public String getLikes() {
        return likes;
    }

    public String getDislikes() {
        return dislikes;
    }

    public String getPath() {
        return path;
    }

    public String getDateTime() {
        return dateTime;
    }

}