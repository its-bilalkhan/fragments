package com.afrididevelopers.novels.angel.models;

public class DownloadsModel {

    public String name, format, path;

    public DownloadsModel(String name, String format, String path) {

        this.name = name;
        this.format = format;
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public String getFormat() {
        return format;
    }

    public String getPath() {
        return path;
    }

}