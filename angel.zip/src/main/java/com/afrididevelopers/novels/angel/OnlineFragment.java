package com.afrididevelopers.novels.angel;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.afrididevelopers.novels.angel.adapters.OnlineAdapter;
import com.afrididevelopers.novels.angel.listeners.RecyclerItemClickListener;
import com.afrididevelopers.novels.angel.models.DownloadsModel;
import com.afrididevelopers.novels.angel.models.OnlineModel;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class OnlineFragment extends Fragment {

    List<OnlineModel> dataList;
    OnlineAdapter adapter;
    RecyclerView recyclerView;
    ProgressBar progressBar;
    LinearLayout notFound;

    private InterstitialAd mInterstitialAd;

    String getDataUrl = "https://afrididev.000webhostapp.com/apps/angel/app/get_data.php";


    public OnlineFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.online_fragment, container, false);

        MobileAds.initialize(getActivity(),
                getResources().getString(R.string.admobAppId));
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        recyclerView = view.findViewById(R.id.recyclerView);
        notFound = view.findViewById(R.id.notFound);
        progressBar = view.findViewById(R.id.progressBar);
        notFound.setVisibility(View.INVISIBLE);


        dataList = new ArrayList<>();
        adapter = new OnlineAdapter(getActivity(), dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getActivity(), recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                OnlineModel data = dataList.get(position);

                Intent intent = new Intent(getActivity(), Details.class);
                intent.putExtra("from", "online");
                intent.putExtra("id", data.getId());
                intent.putExtra("name", data.getName());
                intent.putExtra("pages", data.getPages());
                intent.putExtra("size", data.getSize());
                intent.putExtra("format", data.getFormat());
                intent.putExtra("downloads", data.getDownloads());
                intent.putExtra("likes", data.getLikes());
                intent.putExtra("dislikes", data.getDislikes());
                intent.putExtra("url", data.getPath());
                startActivity(intent);
                showAds();
            }

            @Override
            public void onItemLongClick(View view, int position) {

                showPopupMenu(view, position);
            }
        }));

        loadData();
        return view;
    }

    public void reload() {
        progressBar.setVisibility(View.VISIBLE);
        loadAd();
        loadData();
    }

    public void showPopupMenu(View view, int position){
        Context wrapper = new ContextThemeWrapper(view.getContext(), R.style.popupMenuStyle);
        final PopupMenu popupMenu = new PopupMenu(wrapper, view, Gravity.RIGHT);
        final Menu menu = popupMenu.getMenu();
        popupMenu.getMenuInflater().inflate(R.menu.online_popup_menu, menu);
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.open:
                        OnlineModel data = dataList.get(position);
                        Intent intent = new Intent(getActivity(), Details.class);
                        intent.putExtra("from", "online");
                        intent.putExtra("id", data.getId());
                        intent.putExtra("name", data.getName());
                        intent.putExtra("pages", data.getPages());
                        intent.putExtra("size", data.getSize());
                        intent.putExtra("format", data.getFormat());
                        intent.putExtra("downloads", data.getDownloads());
                        intent.putExtra("likes", data.getLikes());
                        intent.putExtra("dislikes", data.getDislikes());
                        intent.putExtra("url", data.getPath());
                        startActivity(intent);
                        showAds();
                        return true;
                    default:
                        return false;
                }
            }
        });
        popupMenu.show();
    }



    public void loadData() {
        if(!dataList.isEmpty()) {
            dataList.clear();
            adapter.notifyDataSetChanged();
        }
        progressBar.setVisibility(View.VISIBLE);
        final RequestQueue queue = Volley.newRequestQueue(getActivity());
        final StringRequest request = new StringRequest(Request.Method.POST, getDataUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressBar.setVisibility(View.INVISIBLE);
                notFound.setVisibility(View.INVISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    if (jsonArray.length() > 0) { } else {
                        notFound.setVisibility(View.VISIBLE);
                    }
                        for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        if (obj.getString("response").equals("success")) {

                            String id = obj.getString("id");
                            String category = obj.getString("category");
                            String name = obj.getString("name");
                            String author = obj.getString("author");
                            String pages = obj.getString("pages");
                            String size = obj.getString("size");
                            String format = obj.getString("format");
                            String downloads = obj.getString("downloads");
                            String likes = obj.getString("likes");
                            String dislikes = obj.getString("dislikes");
                            String status = obj.getString("status");
                            String url = obj.getString("url");
                            String date_time = obj.getString("date_time");

                            if(status.equals("active")) {
                            OnlineModel data = new OnlineModel(
                                    id,
                                    category,
                                    name,
                                    author,
                                    pages,
                                    size,
                                    format,
                                    downloads,
                                    likes,
                                    dislikes,
                                    "https://afrididev.000webhostapp.com/apps/angel/res/pdf/"+url,
                                    date_time
                                    );
                            dataList.add(data);
                            adapter.notifyDataSetChanged();
                            }

                        } else {
                            Toast.makeText(getActivity(), "Something is wrong! Please refresh", Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    Toast.makeText(getActivity(), "Something is wrong! Please refresh", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(View.INVISIBLE);
                notFound.setVisibility(View.VISIBLE);
                Toast.makeText(getActivity(), "Internal error occurred! Please refresh", Toast.LENGTH_LONG).show();
                Log.i("My error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("get_data", "get_all");

                return map;
            }
        };

        queue.add(request);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAd();
    }

    public void loadAd() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {

        }
    }




}