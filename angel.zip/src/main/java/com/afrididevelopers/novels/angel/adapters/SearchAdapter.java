package com.afrididevelopers.novels.angel.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.afrididevelopers.novels.angel.R;
import com.afrididevelopers.novels.angel.models.SearchModel;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;


public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.MyViewHolder> {

    private List<SearchModel> dataList;
    Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView name;
        String [] array={"#7fe5f0", "#ff80ed", "#bada55", "#f7347a", "#5ac18e", "#dcedc1",
                "#c0c0c0", "#ffc0cb", "#ffe4e1", "#ffa500", "#e6e6fa", "#ff7373", "#00ffff",
                "#40e0d0", "#b0e0e6", "#d3ffce", "#c6e2ff", "#faebd7", "#fa8072", "#7fffd4",
                "#eeeeee", "#ffc3a0", "#ffb6c1", "#f08080", "#ff7f50", "#00ced1", "#c0d6e4",
                "#b4eeb4", "#cbbeb5", "#daa520", "#81d8d0", "#dddddd", "#66cccc", "#a0db8e",
                "#800000", "#ff4040", "#a0db8e", "#8a2be2", "#6897bb", "#794044", "#088da5"};
        ArrayList<String> colors;
        Random random;

        public MyViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.icon);
            name = view.findViewById(R.id.name);
            colors = new ArrayList<String>(Arrays.asList(array));
            random = new Random();
        }
    }


    public SearchAdapter(Context context, List<SearchModel> dataList) {
        this.dataList = dataList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_search_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        SearchModel data = dataList.get(position);

        holder.name.setText(data.getName());

        Glide
                .with(context)
                .load(R.drawable.pdf_icon)
                .placeholder(R.drawable.pdf_icon)
                .into(holder.imageView);

        //    holder.cardView.setCardBackgroundColor(Color.parseColor(holder.colors.get(holder.random.nextInt(holder.colors.size()))));

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}