package com.afrididevelopers.novels.angel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.afrididevelopers.novels.angel.adapters.OnlineAdapter;
import com.afrididevelopers.novels.angel.adapters.SearchAdapter;
import com.afrididevelopers.novels.angel.listeners.RecyclerItemClickListener;
import com.afrididevelopers.novels.angel.models.OnlineModel;
import com.afrididevelopers.novels.angel.models.SearchModel;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Search extends AppCompatActivity {

    ImageView back;
    SearchView search;

    List<SearchModel> dataList;
    SearchAdapter adapter;
    RecyclerView recyclerView;
    ProgressBar progressBar;
    LinearLayout notFound;

    private InterstitialAd mInterstitialAd;
    String searchText = "";
    String getDataUrl = "https://afrididev.000webhostapp.com/apps/angel/app/get_data_search.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        back = findViewById(R.id.back);
        search = findViewById(R.id.search);

        search.setFocusable(false);
        search.setIconified(false);

        MobileAds.initialize(Search.this,
                getResources().getString(R.string.admobAppId));
        mInterstitialAd = new InterstitialAd(Search.this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.admobInterstitialAdId));

        recyclerView = findViewById(R.id.recyclerView);
        notFound = findViewById(R.id.notFound);
        progressBar = findViewById(R.id.progressBar);
        notFound.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.INVISIBLE);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchText = query;
                progressBar.setVisibility(View.VISIBLE);
                loadData();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        dataList = new ArrayList<>();
        adapter = new SearchAdapter(Search.this, dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(Search.this);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(Search.this, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                SearchModel data = dataList.get(position);

                Intent intent = new Intent(Search.this, Details.class);
                intent.putExtra("from", "online");
                intent.putExtra("id", data.getId());
                intent.putExtra("name", data.getName());
                intent.putExtra("pages", data.getPages());
                intent.putExtra("size", data.getSize());
                intent.putExtra("format", data.getFormat());
                intent.putExtra("downloads", data.getDownloads());
                intent.putExtra("likes", data.getLikes());
                intent.putExtra("dislikes", data.getDislikes());
                intent.putExtra("url", data.getPath());
                startActivity(intent);
                showAds();
            }

            @Override
            public void onItemLongClick(View view, int position) {

                showPopupMenu(view, position);
            }
        }));

    }

    public void showPopupMenu(View view, int position){
        Context wrapper = new ContextThemeWrapper(view.getContext(), R.style.popupMenuStyle);
        final PopupMenu popupMenu = new PopupMenu(wrapper, view, Gravity.RIGHT);
        final Menu menu = popupMenu.getMenu();
        popupMenu.getMenuInflater().inflate(R.menu.online_popup_menu, menu);
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.open:
                        SearchModel data = dataList.get(position);
                        Intent intent = new Intent(Search.this, Details.class);
                        intent.putExtra("from", "online");
                        intent.putExtra("id", data.getId());
                        intent.putExtra("name", data.getName());
                        intent.putExtra("pages", data.getPages());
                        intent.putExtra("size", data.getSize());
                        intent.putExtra("format", data.getFormat());
                        intent.putExtra("downloads", data.getDownloads());
                        intent.putExtra("likes", data.getLikes());
                        intent.putExtra("dislikes", data.getDislikes());
                        intent.putExtra("url", data.getPath());
                        startActivity(intent);
                        showAds();
                        return true;
                    default:
                        return false;
                }
            }
        });
        popupMenu.show();
    }

    public void loadData() {
        if(!dataList.isEmpty()) {
            dataList.clear();
            adapter.notifyDataSetChanged();
        }
        final RequestQueue queue = Volley.newRequestQueue(Search.this);
        final StringRequest request = new StringRequest(Request.Method.POST, getDataUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressBar.setVisibility(View.INVISIBLE);
                notFound.setVisibility(View.INVISIBLE);
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    if (jsonArray.length() > 0) { } else {
                        notFound.setVisibility(View.VISIBLE);
                    }
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        if (obj.getString("response").equals("success")) {

                            String id = obj.getString("id");
                            String category = obj.getString("category");
                            String name = obj.getString("name");
                            String author = obj.getString("author");
                            String pages = obj.getString("pages");
                            String size = obj.getString("size");
                            String format = obj.getString("format");
                            String downloads = obj.getString("downloads");
                            String likes = obj.getString("likes");
                            String dislikes = obj.getString("dislikes");
                            String status = obj.getString("status");
                            String url = obj.getString("url");
                            String date_time = obj.getString("date_time");

                            if(status.equals("active")) {
                                SearchModel data = new SearchModel(
                                        id,
                                        category,
                                        name,
                                        author,
                                        pages,
                                        size,
                                        format,
                                        downloads,
                                        likes,
                                        dislikes,
                                        "https://afrididev.000webhostapp.com/apps/angel/res/pdf/"+url,
                                        date_time
                                );
                                dataList.add(data);
                                adapter.notifyDataSetChanged();
                            }

                        } else {
                            Toast.makeText(Search.this, "Something is wrong! Please try again", Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    Toast.makeText(Search.this, "Something is wrong! Please try again", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(View.INVISIBLE);
                notFound.setVisibility(View.VISIBLE);
                Toast.makeText(Search.this, "Internal error occurred! Please try again", Toast.LENGTH_LONG).show();
                Log.i("My error", "" + error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> map = new HashMap<String, String>();
                map.put("get_data", searchText);

                return map;
            }
        };

        queue.add(request);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadAd();
    }

    public void loadAd() {
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void showAds() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {

        }
    }

}